import { useEffect, useRef, useState } from "react";
import { Circle, FabricImage, Rect, Textbox, type FabricObject } from "fabric";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import CanvasEditor from "./components/Canvas/CanvasEditor";
import { useEditor } from "./hooks/useEditor";

const toolbarActions = [
  { key: "templates", label: "Templates", icon: "▦" },
  { key: "elements", label: "Elements", icon: "✦" },
  { key: "text", label: "Text", icon: "T" },
  { key: "gallery", label: "Gallery", icon: "📷" },
  { key: "brand", label: "Brand", icon: "♛" },
  { key: "uploads", label: "Uploads", icon: "⬆" },
  { key: "tools", label: "Tools", icon: "⚙" },
];

type TextState = {
  content: string;
  fontSize: number;
  color: string;
  bold: boolean;
  italic: boolean;
  align: "left" | "center" | "right";
  letterSpacing: number;
  lineHeight: number;
};

const emptyTextState: TextState = {
  content: "",
  fontSize: 58,
  color: "#ffffff",
  bold: false,
  italic: false,
  align: "center",
  letterSpacing: 0,
  lineHeight: 1.2,
};

export default function App() {
  const { canvas, selectedObject, setSelectedObject } = useEditor();
  const passportInputRef = useRef<HTMLInputElement>(null);
  const groupInputRef = useRef<HTMLInputElement>(null);

  const [textState, setTextState] = useState<TextState>(emptyTextState);
  const [selectedText, setSelectedText] = useState<Textbox | null>(null);
  const [selectedImage, setSelectedImage] = useState<FabricImage | null>(null);
  const [layers, setLayers] = useState<FabricObject[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [panel, setPanel] = useState<"tools" | "layers" | "properties" | "uploads">("tools");

  useEffect(() => {
    if (selectedObject instanceof Textbox) {
      setSelectedText(selectedObject);
      setSelectedImage(null);
      setTextState({
        content: selectedObject.text || "",
        fontSize: selectedObject.fontSize ?? 58,
        color: selectedObject.fill?.toString() ?? "#ffffff",
        bold: (selectedObject.fontWeight ?? "normal") === "bold" || Number(selectedObject.fontWeight) >= 700,
        italic: selectedObject.fontStyle === "italic",
        align: (selectedObject.textAlign as TextState["align"]) ?? "center",
        letterSpacing: (selectedObject as Textbox & { charSpacing?: number }).charSpacing ?? 0,
        lineHeight: selectedObject.lineHeight ?? 1.2,
      });
    } else if (selectedObject instanceof FabricImage) {
      setSelectedText(null);
      setSelectedImage(selectedObject);
    } else {
      setSelectedText(null);
      setSelectedImage(null);
    }
  }, [selectedObject]);

  useEffect(() => {
    if (!canvas) return;

    const refreshLayers = () => {
      setLayers(canvas.getObjects().filter((object) => (object as FabricObject & { name?: string }).name));
    };

    refreshLayers();
    canvas.on("object:added", refreshLayers);
    canvas.on("object:removed", refreshLayers);
    canvas.on("object:modified", refreshLayers);

    return () => {
      canvas.off("object:added", refreshLayers);
      canvas.off("object:removed", refreshLayers);
      canvas.off("object:modified", refreshLayers);
    };
  }, [canvas]);

  const updateSelectedText = (updates: Partial<Textbox>) => {
    if (!canvas || !selectedText) return;
    selectedText.set(updates);
    canvas.requestRenderAll();
    setSelectedObject(selectedText);
  };

  const handleTextChange = (field: keyof TextState, value: string | number | boolean) => {
    if (!selectedText || !canvas) return;

    const nextState = { ...textState, [field]: value } as TextState;
    setTextState(nextState);

    const update: Partial<Textbox> = {};
    if (field === "content") update.text = String(value);
    if (field === "fontSize") update.fontSize = Number(value);
    if (field === "color") update.fill = String(value);
    if (field === "bold") update.fontWeight = Boolean(value) ? "bold" : "normal";
    if (field === "italic") update.fontStyle = Boolean(value) ? "italic" : "normal";
    if (field === "align") update.textAlign = value as "left" | "center" | "right";
    if (field === "letterSpacing") update.charSpacing = Number(value);
    if (field === "lineHeight") update.lineHeight = Number(value);

    selectedText.set(update);
    canvas.requestRenderAll();
    setSelectedObject(selectedText);
  };

  const readAndApplyImage = (file: File, mode: "passport" | "group") => {
    if (!canvas) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const image = new Image();
      image.onload = () => {
        const frame = canvas.getObjects().find((object) => (object as FabricObject & { name?: string }).name === (mode === "passport" ? "passportFrame" : "groupFrame"));
        const left = frame?.left ?? (mode === "passport" ? 280 : 800);
        const top = frame?.top ?? (mode === "passport" ? 320 : 400);

        const fabricImage = new FabricImage(image, {
          name: mode === "passport" ? "passportImage" : "groupImage",
          left,
          top,
          originX: "center",
          originY: "center",
          selectable: true,
          objectCaching: false,
          cornerStyle: "circle",
          transparentCorners: false,
          borderColor: "#d4af37",
          cornerColor: "#d4af37",
        });

        const existing = canvas.getObjects().find((object) => (object as FabricObject & { name?: string }).name === (fabricImage as FabricObject & { name?: string }).name);
        if (existing) {
          canvas.remove(existing);
        }

        if (mode === "passport") {
          const clipPath = new Circle({
            radius: 140,
            originX: "center",
            originY: "center",
            fill: "transparent",
            selectable: false,
            evented: false,
          });
          fabricImage.set({ clipPath, scaleX: 1, scaleY: 1 });
          fabricImage.scaleToWidth(280);
        } else {
          const clipPath = new Rect({
            width: 560,
            height: 420,
            originX: "center",
            originY: "center",
            fill: "transparent",
            selectable: false,
            evented: false,
          });
          fabricImage.set({ clipPath, scaleX: 1, scaleY: 1 });
          fabricImage.scaleToWidth(560);
        }

        canvas.add(fabricImage);
        canvas.setActiveObject(fabricImage);
        setSelectedObject(fabricImage as FabricObject);
        canvas.requestRenderAll();
      };
      image.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleLayerSelect = (object: FabricObject) => {
    if (!canvas) return;
    canvas.setActiveObject(object);
    canvas.requestRenderAll();
    setSelectedObject(object);
  };

  const moveLayer = (direction: "front" | "back") => {
    if (!canvas || !selectedObject) return;
    if (direction === "front") {
      (selectedObject as any).bringToFront?.();
    } else {
      (selectedObject as any).sendToBack?.();
    }
    canvas.requestRenderAll();
  };

  const toggleLayerLock = () => {
    if (!canvas || !selectedObject) return;
    const nextValue = !selectedObject.selectable;
    selectedObject.set({ selectable: nextValue, evented: nextValue });
    canvas.requestRenderAll();
    setSelectedObject(selectedObject);
  };

  const rotateSelectedImage = (angle: number) => {
    if (!selectedImage || !canvas) return;
    selectedImage.rotate((selectedImage.angle ?? 0) + angle);
    canvas.requestRenderAll();
  };

  const flipSelectedImage = (axis: "x" | "y") => {
    if (!selectedImage || !canvas) return;
    selectedImage.set({
      scaleX: axis === "x" ? -(selectedImage.scaleX ?? 1) : selectedImage.scaleX ?? 1,
      scaleY: axis === "y" ? -(selectedImage.scaleY ?? 1) : selectedImage.scaleY ?? 1,
    });
    canvas.requestRenderAll();
  };

  const exportCanvas = (type: "png" | "jpg" | "pdf") => {
    if (!canvas) return;

    const dataUrl = canvas.toDataURL({
      format: type === "jpg" ? "jpeg" : "png",
      quality: 1,
      multiplier: 1,
    });

    if (type === "pdf") {
      const pdf = new jsPDF({ orientation: "portrait", unit: "px", format: [3000, 3600] });
      pdf.addImage(dataUrl, "PNG", 0, 0, 3000, 3600);
      pdf.save("graduation-enlargement.pdf");
      return;
    }

    const blob = dataUrlToBlob(dataUrl);
    saveAs(blob, `graduation-enlargement.${type}`);
  };

  const handleUpload = (mode: "passport" | "group") => {
    if (mode === "passport") passportInputRef.current?.click();
    else groupInputRef.current?.click();
    setMenuOpen(false);
  };

  const openPanel = (nextPanel: "tools" | "layers" | "properties" | "uploads") => {
    setPanel(nextPanel);
    setMenuOpen(true);
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbarStart">
          <button className="iconButton" onClick={() => setMenuOpen((value) => !value)} aria-label="Open menu">
            ☰
          </button>
        </div>

        <div className="topbarCenter">
          <div className="titleLine">Graduation Studio</div>
          <div className="subtitleLine">Create print-ready enlargements</div>
        </div>

        <div className="topbarEnd">
          <button className="iconButton" onClick={() => handleUpload("passport")} aria-label="Upload Passport">
            ⬆
          </button>
          <button className="iconButton" onClick={() => handleUpload("group")} aria-label="Upload Group Photo">
            🖼
          </button>
          <button className="iconButton" onClick={() => exportCanvas("png")} aria-label="Export PNG">
            ⤴
          </button>
        </div>
      </header>

      {menuOpen && (
        <div className="sheetOverlay" onClick={() => setMenuOpen(false)}>
          <div className="sheet" onClick={(event) => event.stopPropagation()}>
            <div className="sheetHeader">
              <div className="sheetTitle">Quick Menu</div>
              <button className="iconButton small" onClick={() => setMenuOpen(false)} aria-label="Close menu">
                ✕
              </button>
            </div>
            <div className="sheetContent">
              <button onClick={() => openPanel("tools")}>Templates / Elements</button>
              <button onClick={() => openPanel("properties")}>Text</button>
              <button onClick={() => openPanel("uploads")}>Uploads</button>
              <button onClick={() => openPanel("layers")}>Layers</button>
              <button onClick={() => exportCanvas("png")}>Export PNG</button>
              <button onClick={() => exportCanvas("jpg")}>Export JPG</button>
              <button onClick={() => exportCanvas("pdf")}>Export PDF</button>
            </div>
          </div>
        </div>
      )}

      <input
        ref={passportInputRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) readAndApplyImage(file, "passport");
          event.target.value = "";
        }}
      />
      <input
        ref={groupInputRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) readAndApplyImage(file, "group");
          event.target.value = "";
        }}
      />

      <main className="workspace">
        <section className="canvasArea">
          <div className="canvasCard">
            <CanvasEditor />
          </div>
        </section>

        {menuOpen && (
          <div className="sheet">
            <div className="sheetContent">
              {panel === "tools" && (
                <>
                  <h3>Quick Actions</h3>
                  <button onClick={() => passportInputRef.current?.click()}>Upload Passport</button>
                  <button onClick={() => groupInputRef.current?.click()}>Upload Group Photo</button>
                  <button onClick={() => openPanel("properties")}>Text Options</button>
                  <button onClick={() => exportCanvas("png")}>Export PNG</button>
                  <button onClick={() => exportCanvas("jpg")}>Export JPG</button>
                  <button onClick={() => exportCanvas("pdf")}>Export PDF</button>
                </>
              )}

              {panel === "uploads" && (
                <>
                  <h3>Uploads</h3>
                  <button onClick={() => passportInputRef.current?.click()}>Upload Passport</button>
                  <button onClick={() => groupInputRef.current?.click()}>Upload Group Photo</button>
                  <button onClick={() => openPanel("tools")}>Back to Actions</button>
                </>
              )}

              {panel === "layers" && (
                <>
                  <h3>Layers</h3>
                  {layers.length === 0 ? (
                    <p className="hint">Your layers will appear here.</p>
                  ) : (
                    layers.map((object) => (
                      <button key={String((object as FabricObject & { name?: string }).name ?? "layer")} className="layerItem" onClick={() => handleLayerSelect(object)}>
                        {(object as FabricObject & { name?: string }).name ?? "layer"}
                      </button>
                    ))
                  )}
                  <div className="miniActions">
                    <button onClick={() => moveLayer("front")}>Bring Front</button>
                    <button onClick={() => moveLayer("back")}>Send Back</button>
                    <button onClick={() => toggleLayerLock()}>{selectedObject?.selectable === false ? "Unlock" : "Lock"}</button>
                  </div>
                </>
              )}

              {panel === "properties" && (
                <>
                  <h3>Properties</h3>
                  {selectedText ? (
                    <div className="panelBlock">
                      <label>
                        Text
                        <textarea value={textState.content} onChange={(event) => handleTextChange("content", event.target.value)} />
                      </label>
                      <label>
                        Font size
                        <input type="number" value={textState.fontSize} onChange={(event) => handleTextChange("fontSize", Number(event.target.value))} />
                      </label>
                      <label>
                        Color
                        <input type="color" value={textState.color} onChange={(event) => handleTextChange("color", event.target.value)} />
                      </label>
                      <div className="toggleRow">
                        <label><input type="checkbox" checked={textState.bold} onChange={(event) => handleTextChange("bold", event.target.checked)} /> Bold</label>
                        <label><input type="checkbox" checked={textState.italic} onChange={(event) => handleTextChange("italic", event.target.checked)} /> Italic</label>
                      </div>
                      <label>
                        Alignment
                        <select value={textState.align} onChange={(event) => handleTextChange("align", event.target.value)}>
                          <option value="left">Left</option>
                          <option value="center">Center</option>
                          <option value="right">Right</option>
                        </select>
                      </label>
                      <label>
                        Letter spacing
                        <input type="number" value={textState.letterSpacing} onChange={(event) => handleTextChange("letterSpacing", Number(event.target.value))} />
                      </label>
                      <label>
                        Line height
                        <input type="number" step="0.1" value={textState.lineHeight} onChange={(event) => handleTextChange("lineHeight", Number(event.target.value))} />
                      </label>
                    </div>
                  ) : selectedImage ? (
                    <div className="panelBlock">
                      <p className="hint">Image selected. Replace it or adjust its orientation.</p>
                      <button onClick={() => groupInputRef.current?.click()}>Replace Image</button>
                      <div className="miniActions">
                        <button onClick={() => rotateSelectedImage(-90)}>Rotate Left</button>
                        <button onClick={() => rotateSelectedImage(90)}>Rotate Right</button>
                      </div>
                      <div className="miniActions">
                        <button onClick={() => flipSelectedImage("x")}>Flip X</button>
                        <button onClick={() => flipSelectedImage("y")}>Flip Y</button>
                      </div>
                    </div>
                  ) : (
                    <div className="panelBlock">
                      <p className="hint">Select a text box or image to edit its properties.</p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        <div className="bottomToolbar">
          {toolbarActions.map((action) => (
            <button
              key={action.key}
              onClick={() => {
                switch (action.key) {
                  case "templates":
                  case "elements":
                  case "gallery":
                  case "brand":
                    openPanel("tools");
                    break;
                  case "text":
                    openPanel("properties");
                    break;
                  case "uploads":
                    openPanel("uploads");
                    break;
                  case "tools":
                    openPanel("tools");
                    break;
                }
              }}
            >
              <span className="iconLabel">{action.icon}</span>
              <span className="bottomLabel">{action.label}</span>
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}

function dataUrlToBlob(dataUrl: string) {
  const [header, body] = dataUrl.split(",");
  const mime = header.match(/data:(.*?);/)?.[1] ?? "image/png";
  const binary = atob(body);
  const array = new Uint8Array(binary.length);

  for (let index = 0; index < binary.length; index += 1) {
    array[index] = binary.charCodeAt(index);
  }

  return new Blob([array], { type: mime });
}
import { useEffect, useRef } from "react";
import { Canvas, Rect, Circle, Textbox } from "fabric";
import { useEditor } from "../../hooks/useEditor";

export default function CanvasEditor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { setCanvas, setSelectedObject } = useEditor();

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = new Canvas(canvasRef.current, {
      width: 1200,
      height: 900,
      backgroundColor: "#08111f",
      preserveObjectStacking: true,
      selection: true,
    });

    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    canvas.setZoom(1);
    setCanvas(canvas);

    canvas.on("selection:created", (event) => {
      setSelectedObject(event.selected?.[0] ?? null);
    });

    canvas.on("selection:updated", (event) => {
      setSelectedObject(event.selected?.[0] ?? null);
    });

    canvas.on("selection:cleared", () => {
      setSelectedObject(null);
    });

    const page = new Rect({
      left: 60,
      top: 40,
      width: 1080,
      height: 820,
      fill: "#090f1c",
      stroke: "#1f2a4f",
      strokeWidth: 5,
      selectable: false,
      evented: false,
      rx: 32,
      ry: 32,
      name: "pageBackground",
    });
    canvas.add(page);

    const topGlow = new Rect({
      left: 120,
      top: 68,
      width: 960,
      height: 220,
      fill: "rgba(255, 255, 255, 0.04)",
      selectable: false,
      evented: false,
      rx: 28,
      ry: 28,
      name: "topGlow",
    });
    canvas.add(topGlow);

    const passportFrame = new Circle({
      left: 360,
      top: 360,
      radius: 190,
      fill: "rgba(255,255,255,0.06)",
      stroke: "#d4af37",
      strokeWidth: 12,
      selectable: false,
      evented: false,
      name: "passportFrame",
    });
    canvas.add(passportFrame);

    const groupFrame = new Rect({
      left: 760,
      top: 280,
      width: 380,
      height: 360,
      fill: "rgba(255,255,255,0.05)",
      stroke: "#d4af37",
      strokeWidth: 12,
      selectable: false,
      evented: false,
      rx: 24,
      ry: 24,
      name: "groupFrame",
    });
    canvas.add(groupFrame);

    const school = new Textbox("HARVEST OF KNOWLEDGE\nINTERNATIONAL SCHOOL", {
      left: 600,
      top: 84,
      width: 900,
      fontSize: 42,
      fontWeight: "bold",
      textAlign: "center",
      fill: "#ffffff",
      originX: "center",
      lineHeight: 1.05,
      name: "schoolName",
    });
    canvas.add(school);

    const address = new Textbox("NO. 24 NWIGWE STREET, EBONY PAINT ROAD, ENUGU", {
      left: 600,
      top: 186,
      width: 860,
      fontSize: 18,
      textAlign: "center",
      fill: "#d4c789",
      originX: "center",
      name: "address",
    });
    canvas.add(address);

    const sessionRibbon = new Rect({
      left: 120,
      top: 560,
      width: 470,
      height: 84,
      fill: "#d4af37",
      rx: 24,
      ry: 24,
      selectable: false,
      evented: false,
      name: "sessionRibbon",
    });
    canvas.add(sessionRibbon);

    const sessionText = new Textbox("2025/2026 PRIMARY 6 GRADUATES", {
      left: 360,
      top: 578,
      width: 420,
      fontSize: 24,
      fontWeight: "bold",
      textAlign: "center",
      fill: "#09111f",
      originX: "center",
      selectable: false,
      evented: false,
      name: "session",
    });
    canvas.add(sessionText);

    const studentBackground = new Rect({
      left: 100,
      top: 660,
      width: 980,
      height: 128,
      fill: "rgba(212, 175, 55, 0.15)",
      rx: 32,
      ry: 32,
      selectable: false,
      evented: false,
      name: "studentBackground",
    });
    canvas.add(studentBackground);

    const student = new Textbox("STUDENT NAME", {
      left: 600,
      top: 684,
      width: 840,
      fontSize: 48,
      fontWeight: "bold",
      textAlign: "center",
      fill: "#ffffff",
      originX: "center",
      name: "studentName",
    });
    canvas.add(student);

    canvas.renderAll();

    return () => {
      canvas.dispose();
      setCanvas(null);
    };
  }, []);

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#1b1b1b",
        overflow: "auto",
      }}
    >
      <canvas ref={canvasRef} />
    </div>
  );
}
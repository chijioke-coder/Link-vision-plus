import {
  createContext,
  useContext,
  useState,
  ReactNode
} from "react";

import { Canvas, FabricObject } from "fabric";
import { EditorContextType } from "../types/editor";

const EditorContext =
  createContext<EditorContextType | null>(null);

export function EditorProvider({
  children
}: {
  children: ReactNode;
}) {

  const [canvas, setCanvas] =
    useState<Canvas | null>(null);

  const [selectedObject, setSelectedObject] =
    useState<FabricObject | null>(null);

  return (
    <EditorContext.Provider
      value={{
        canvas,
        setCanvas,
        selectedObject,
        setSelectedObject
      }}
    >
      {children}
    </EditorContext.Provider>
  );
}

export function useEditor() {

  const context = useContext(EditorContext);

  if (!context)
    throw new Error(
      "useEditor must be used inside EditorProvider."
    );

  return context;
}
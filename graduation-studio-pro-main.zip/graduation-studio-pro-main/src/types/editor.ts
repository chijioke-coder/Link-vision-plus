import { Canvas, FabricObject } from "fabric";

export interface EditorContextType {
  canvas: Canvas | null;
  setCanvas: (canvas: Canvas | null) => void;

  selectedObject: FabricObject | null;
  setSelectedObject: (object: FabricObject | null) => void;
}

import heroImage from "@/assets/hero-skincare.jpg";

const HeroSection = () => {
  return (
    <section id="hero" className="relative min-h-[90vh] flex items-end pb-16 pt-24 overflow-hidden">
      <img
        src={heroImage}
        alt="Premium Zashaura skincare products on marble surface"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
        <h2 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-4 text-foreground">
          The Science<br />of Your Glow.
        </h2>
        <p className="text-muted-foreground text-lg md:text-xl max-w-md mb-8 font-light">
          Dermatologist-approved skincare delivered to your door.
        </p>
        <a
          href="#products"
          className="inline-block gold-gradient gold-glow text-primary-foreground font-semibold px-8 py-4 rounded-full text-lg transition-transform hover:scale-105 active:scale-95"
        >
          Shop Best Sellers
        </a>
      </div>
    </section>
  );
};

export default HeroSection;

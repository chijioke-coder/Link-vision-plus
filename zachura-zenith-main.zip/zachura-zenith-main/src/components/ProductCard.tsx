import { useState } from "react";
import CheckoutModal from "./CheckoutModal";

interface ProductCardProps {
  image: string;
  name: string;
  price: string;
  index: number;
}

const ProductCard = ({ image, name, price, index }: ProductCardProps) => {
  const [showCheckout, setShowCheckout] = useState(false);

  return (
    <>
      <div
        className="glass rounded-card overflow-hidden group transition-transform hover:scale-[1.02] active:scale-[0.98]"
        style={{ animationDelay: `${index * 100}ms` }}
      >
        <div className="aspect-square overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        </div>
        <div className="p-4">
          <h3 className="font-display text-base font-semibold text-foreground mb-1">{name}</h3>
          <p className="text-gold font-bold text-lg mb-3">{price}</p>
          <button
            onClick={() => setShowCheckout(true)}
            className="w-full gold-gradient gold-glow text-primary-foreground font-semibold py-3 rounded-full text-sm transition-transform hover:scale-105 active:scale-95"
          >
            Quick Buy
          </button>
        </div>
      </div>

      <CheckoutModal
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        productName={name}
        productPrice={price}
      />
    </>
  );
};

export default ProductCard;

import ProductCard from "./ProductCard";

const products = [
  {
    image: "https://i.postimg.cc/VvBS7P49/Atralia_Elixir_it_is_a_fresh_sweet_and_warm_Oriental_Fougere_scent_often_compared_favora.jpg",
    name: "Atralia Elixir",
    price: "₦200,000",
  },
  {
    image: "https://i.postimg.cc/XqcZ26xF/Ck_obsession_for_women_This_is_a_classic_intense_Oriental_Spicy_fragrance_featuring_notes.jpg",
    name: "CK Obsession",
    price: "₦300,000",
  },
  {
    image: "https://i.postimg.cc/KjrK9hQD/IMG_20260401_215752_849.png",
    name: "Zashaura Glow Serum",
    price: "₦150,000",
  },
  {
    image: "https://i.postimg.cc/VvBS7P4F/IMG_20260401_215828_620.png",
    name: "Zashaura Night Cream",
    price: "₦77,000",
  },
];

const ProductsGrid = () => {
  return (
    <section id="products" className="max-w-7xl mx-auto px-4 py-20">
      <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-3 text-foreground">
        The Essentials
      </h2>
      <p className="text-muted-foreground text-center mb-12 text-lg">
        Curated for radiance
      </p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {products.map((product, i) => (
          <ProductCard key={product.name} {...product} index={i} />
        ))}
      </div>
    </section>
  );
};

export default ProductsGrid;
